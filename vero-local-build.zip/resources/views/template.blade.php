@include("includes.header")
<span class="howhide">

@include("includes.full_header")
</span>

	<?php echo $content ?>	

<div id="body2">
    @include("includes.footer")
</div>