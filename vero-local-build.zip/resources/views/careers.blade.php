@include("includes.header")
<span class="howhide">

@include("includes.full_header")
</span>

<div class="container">
	career	
</div>

<div id="body2">
    @include("includes.footer")
</div>