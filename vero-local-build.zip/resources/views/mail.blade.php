<table cellpadding="10" cellspacing="0" width="700" style="margin:0 auto;border-top:3px solid #555555;border-collapse:collapse;overflow:hidden">
    <tbody><tr class="m_535418000565208981m_2355994979619036339m_-4060298380300999308table-head m_535418000565208981m_2355994979619036339m_-4060298380300999308blue_border" style="border-bottom:8px solid #ff9200;text-align:center">
        <td style="width:30%"></td><td style="width:40%"><a href="#" rel="noreferrer" target="_blank" data-saferedirecturl="">{{ $title }}</a></td><td style="width:30%"></td></tr>
    <tr><td colspan="3">Hi <span class="m_535418000565208981m_2355994979619036339m_-4060298380300999308amaze-user">{{ $username }},<br><p>{{ $message }}</p></span></td></tr>


    <tr><td colspan="3">Thanks!<br>Vero1 Team</td></tr>
    <tr style="text-align:center"><td colspan="3"><p><a height="40" width="420" class="m_535418000565208981m_2355994979619036339m_-4060298380300999308btn_link" style="background:#ff9200;padding:0 10px;border-radius:3px;display:inline-block;color:#fff;font-size:16px;height:40px;min-width:100px;max-width:420px;line-height:38px;text-decoration:none" href="{{ $action_link }}" rel="noreferrer" target="_blank" data-saferedirecturl="{{ $action_link }}">{{ $action }}</a></p></td></tr>
    <tr class="m_535418000565208981m_2355994979619036339m_-4060298380300999308blue_border" style="border-bottom:8px solid #ff9200" height="" width="700"><td colspan="3"></td></tr>

    </tbody></table>
