@include("includes.header")
<span class="howhide">
@include("includes.full_header")
</span>

@include('includes.footer')