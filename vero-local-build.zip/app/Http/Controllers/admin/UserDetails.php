<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\Users;
use App\Logs;
use App\Wallets;
use App\FeedBacks;
use App\Purchases;
use App\DriverPurchases;
use App\PurchasesFlows;
use MongoDB\BSON\ObjectId;

class UserDetails extends Controller
{
    public function __construct()
    {

    }

    public function riders()
    {
      $users = Users::where('user_type', 'user')
                ->orderBy('_id', 'desc')
                ->get();

      return view("admin.user")->with('users',$users);
    }

    public function drivers()
    {
      $users = Users::where('user_type', 'driver')
                ->orderBy('_id', 'desc')
                ->get();

      return view("admin.user")->with('users',$users);
    }

    public function details($id)
    {
      $detail_id = base64_decode($id);

      $users = Users::where('_id', $detail_id)
                ->get();

      $driverPurchases = DriverPurchases::where('driver_id', new ObjectId($detail_id))
                ->get();

      $driverRides = [];

      if( count($driverPurchases) > 0)
      {
          foreach($driverPurchases as $key=>$purchases)
          {

            $purchasesItems = Purchases::where('_id', new ObjectId($purchases->purchase_id))->get();
            if(count($purchasesItems) > 0)
            {
              array_push($driverRides, $purchasesItems);
            }
          }

      }

      $data = ['driver'=>$users, 'driver_purchases'=>$driverRides];

      return view('admin.user_details')->with('data', $data);

    }
}
