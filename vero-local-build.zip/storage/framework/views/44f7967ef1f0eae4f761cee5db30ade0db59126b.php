<title>Paper Dashboard by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(URL::to("assets/css/bootstrap.min.css")); ?>" rel="stylesheet" />
    <!-- Animation library for notifications   -->
    <link href="<?php echo e(URL::to("/")); ?>/assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Paper Dashboard core CSS    -->
    <link href="<?php echo e(URL::to("/")); ?>/assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo e(URL::to("/")); ?>/assets/css/demo.css" rel="stylesheet" />
    <!--  Fonts and icons     -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo e(URL::to("/")); ?>/assets/css/themify-icons.css" rel="stylesheet">
    <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
    

</head>
<body>
