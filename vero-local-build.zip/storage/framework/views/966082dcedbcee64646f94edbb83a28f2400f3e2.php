<?php echo $__env->make("includes.header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<span class="howhide">

<?php echo $__env->make("includes.full_header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</span><div class="bgs">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 sampepage">
            <div class="card">
                <div class="card-header loginfont"><?php echo e(__('Reset Password')); ?></div>

                <div class="card-body">
				<?php
				
				echo "<pre style='display:none'>";
				print_r(session()->all());
				
				echo "</pre>";
					
			
				?>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')[0]); ?>

                        </div>
                    <?php endif; ?>
 
					<?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')[0]); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('passwordReset')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>  vero-field" name="email" value="<?php echo e(old('email')); ?>" required placeholder="example@example.com">

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary vero2 vero-btn1">
                                    <?php echo e(__('Send Password Reset Link')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div id="body2">
    <?php echo $__env->make("includes.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
